<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>



<?php
require 'connection.php';
$_SESSION["id"] = 1; // User's session
$sessionId = $_SESSION["id"];
$user = mysqli_fetch_assoc(mysqli_query($conn, "SELECT * FROM tb_user WHERE id = $sessionId"));
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>Update Image Profile</title>
    <link rel="stylesheet" href="styles.css">
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
         <!--Favicon-->
    <link style="border-radius: 7px;" href="logo/logo2.png" width="60px" rel="icon">
    <link style="border-radius: 7px;" href="logo/logo2.png" width="60px" rel="apple-touch-icon">

    <!---------Css-------->

    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='welcome.css'>

    <!-----Google font----->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Sofia+Sans+Condensed:wght@300&display=swap" rel="stylesheet">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Aleo:wght@400;700&             display=swap" rel="stylesheet">

    <!-----Fontawesome----->
    <link rel="stylesheet" href="https://kit.fontawesome.com/f4de1cba20.css" crossorigin="anonymous">
    <script src="https://kit.fontawesome.com/f4de1cba20.js" crossorigin="anonymous"></script>

    <!------Bootstrap------>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">

  
  
  <style>
    .upload{
  width: 125px;
  position: relative;
  margin: auto;
}

.upload img{
  border-radius: 50%;
  border: 8px solid #DCDCDC;
}

.upload .round{
  position: absolute;
  bottom: 0;
  right: 0;
  background: #00B4FF;
  width: 32px;
  height: 32px;
  line-height: 33px;
  text-align: center;
  border-radius: 50%;
  overflow: hidden;
}

.upload .round input[type = "file"]{
  position: absolute;
  transform: scale(2);
  opacity: 0;
}

input[type=file]::-webkit-file-upload-button{
    cursor: pointer;
}



* {
    margin: 0;
    padding: 0;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300&family=Sofia+Sans+Condensed:wght@300&display=swap');
@media only screen and(max) {}

body {
    font-family: sans-serif;
    font-family: 'Aleo', serif;
}

.body {
    background-color: #f9f4f4;
}


/* Navbar Css */

.navbar-main {
    background-image: url(images/nav.png);
    display: flex;
}

.search-bar-back {
    background-color: white;
    height: 50px;
    border-radius: 4px;
}

.search-bar-back input {
    margin-top: 6px;
}

.search-bar2 {
    margin-top: 8px;
    padding-left: 7px;
    padding-right: 7px;
}

.login-button button {
    width: 100px;
    margin-top: 0px;
}

.login-button button {
    border: 1px solid #4CAF50;
    border-radius: 5px;
}

.login-button button i {
    font-weight: 600;
    margin-left: 5px;
}

.login-button button span {
    margin-left: 5px;
}

.nav-div button {
    height: 35px;
    width: 70px;
    background-color: white;
    border-radius: 5px;
    border: none;
    margin-top: 8px;
    border: 1px solid rgb(203, 177, 177);
}

.nav-div button i {
    color: black;
}

.login-button button {
    border: 1px solid #4CAF50;
    border-radius: 5px;
    padding: 2px;
    margin-top: 5px;
    height: 35px;
    width: 100px;
    background-color: white;
}

.login-button button:hover {
    color: white;
    background-color: #4CAF50;
    transition: 0.5s;
}

.login-button button i {
    font-weight: 600;
    margin-left: 5px;
}

.login-button button span {
    margin-left: 5px;
}

.log-in-back {
    background-color: white;
    height: 50px;
    border-radius: 4px;
}

.manue-bar {
    height: 45px;
    background-color: #4CAF50;
}

#rku {
    background-color: white;
}

#rku a {
    color: navy;
}

.manue-bar-design {
    display: flex;
    font-family: 'Times New Roman', Times, serif;
    font-weight: 700;
}

.manue-bar-design a i {
    color: white;
}

.manue-home a {
    margin-top: 10px;
}

.nabar-link {
    display: flex;
    background-color: #B4161B;
    height: 45px;
}

.nabar-link div {
    display: flex;
    width: 100px;
    text-align: center;
    justify-content: center;
}

.nabar-link div:hover {
    background-color: #4CAF50;
    transition: 0.5s;
    height: 45px;
}

.nabar-link div a {
    text-decoration: none;
    font-weight: 700;
    color: white;
    font-family: 'Times New Roman', Times, serif;
    margin-top: 10px;
    margin-left: 5px;
    padding: 0px;
}

#dbms {
    width: 100px;
}

.nabar-link div a i {
    margin: 3px;
}

.arrow-button {
    margin-bottom: 80px;
    font-size: 25px;
    font-weight: 700;
    margin-right: 26px;
}

.chat-icon-div {
    margin-bottom: 20px;
    margin-left: 20px;
}

.chat-icon-div-img {
    height: 50px;
    border-radius: 50%;
    margin-top: 100px;
    margin-right: 10px;
}


/*-------------------------------- Manue end --------------------------------*/

.main-body {
    height: 300px;
    background-color: white;
}

.user-pic {
    border-radius: 50%;
    display: block;
    margin-left: auto;
    margin-right: auto;
}



   </style>
  
  
  </head>
  <body>
  
  
  
   <div class="d-flex navbar-main">
        <div class="m-1">
            <a href="index.html"><img src="logo/logo3.png" width="160" alt="" class="my-1"></a>
        </div>

        <div class="ml-auto login-button m-2">
            <a href="welcome2.php"> <button> <i class="fa-regular fa-user"></i> <span><?php echo htmlspecialchars($_SESSION["username"]); ?></span> </button></a>
        </div>
    </div>
  
  
  
  
    <form class="form my-3" id = "form" action="" enctype="multipart/form-data" method="post">
      <div class="upload">
        <?php
        $id = $user["id"];
        $name = $user["name"];
        $image = $user["image"];
        ?>
        <img src="img/<?php echo $image; ?>" width = 125 height = 125 title="<?php echo $image; ?>">
        <div class="round">
          <input type="hidden" name="id" value="<?php echo $id; ?>">
          <input type="hidden" name="name" value="<?php echo $name; ?>">
          <input type="file" name="image" id = "image" accept=".jpg, .jpeg, .png">
          <i class = "fa fa-camera" style = "color: #fff;"></i>
        </div>
      </div>
    </form>
    <script type="text/javascript">
      document.getElementById("image").onchange = function(){
          document.getElementById("form").submit();
      };
    </script>
    <?php
    if(isset($_FILES["image"]["name"])){
      $id = $_POST["id"];
      $name = $_POST["name"];

      $imageName = $_FILES["image"]["name"];
      $imageSize = $_FILES["image"]["size"];
      $tmpName = $_FILES["image"]["tmp_name"];

      // Image validation
      $validImageExtension = ['jpg', 'jpeg', 'png'];
      $imageExtension = explode('.', $imageName);
      $imageExtension = strtolower(end($imageExtension));
      if (!in_array($imageExtension, $validImageExtension)){
        echo
        "
        <script>
          alert('Invalid Image Extension');
          document.location.href = '../updateimageprofile';
        </script>
        ";
      }
      elseif ($imageSize > 1200000){
        echo
        "
        <script>
          alert('Image Size Is Too Large');
          document.location.href = '../updateimageprofile';
        </script>
        ";
      }
      else{
        $newImageName = $name . " - " . date("Y.m.d") . " - " . date("h.i.sa"); // Generate new image name
        $newImageName .= '.' . $imageExtension;
        $query = "UPDATE tb_user SET image = '$newImageName' WHERE id = $id";
        mysqli_query($conn, $query);
        move_uploaded_file($tmpName, 'img/' . $newImageName);
        echo
        "
        <script>
        document.location.href = '../updateimageprofile';
        </script>
        ";
      }
    }
    ?>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js" integrity="sha384-w76AqPfDkMBDXo30jS1Sgez6pr3x5MlQ1ZAGC+nuZB+EYdgRZgiwxhTBTkF7CXvN" crossorigin="anonymous"></script>

  </body>
</html>
