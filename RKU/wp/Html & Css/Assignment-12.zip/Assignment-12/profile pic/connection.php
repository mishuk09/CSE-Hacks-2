<?php
$conn = mysqli_connect("sql313.epizy.com", "epiz_33630939", "5Q0xsxMe5XEn", "epiz_33630939_loginsystem");
